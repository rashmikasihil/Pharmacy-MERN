import React from 'react'

const EditFruit = () => {
  return (
    <div>
        <h1>Edit Fruit Here..</h1>
        </div>
  )
}

export default EditFruit