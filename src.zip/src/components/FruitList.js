import React from 'react'

const FruitList = () => {
  return (
    <div>
        <h1>List Of Fruit Here...</h1>
        </div>
  )
}

export default FruitList