import React from 'react'

const AddFruit = () => {
  return (
    <div>
        <h1>Add Fruit Here..</h1>
    </div>
  )
}

export default AddFruit