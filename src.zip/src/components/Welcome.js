import React from 'react'

const Welcome = () => {
  return (
    <div>
        <h1>Welcome To The Welcome Page</h1>
        </div>
  )
}

export default Welcome